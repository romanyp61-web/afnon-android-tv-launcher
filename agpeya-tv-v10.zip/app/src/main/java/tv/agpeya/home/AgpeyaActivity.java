package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.LocalDateTime;

/** The Agpeya page: today's seven hours (tap = prayed, hold = find it on YouTube), the next prayer, the fast and the verse. */
public class AgpeyaActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout stage;
    private TextView clock, ampm, dateC, dateG, nextPill;
    private final TextView[] tags = new TextView[7];
    private final TextView[] times = new TextView[7];
    private final View[] tiles = new View[7];
    private int shownMask = -1, shownNext = -1;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        setContentView(build());
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (int i = 0; i < 7; i++) times[i].setText(Agpeya.clock(Agpeya.minutes(this, i)));
        shownMask = -1;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    private <T extends View> T put(T v, float x, float y, float w, float h) {
        stage.addView(v, Ui.at(this, x, y, w, h));
        return v;
    }

    private void card(float x, float y, float w, float h) {
        View v = new View(this);
        v.setBackground(Ui.rect(this, Ui.glass(0xB8), 0x59D4AF6A, 1.5f, 26));
        put(v, x, y, w, h);
    }

    private TextView pill(String label, float x, float w, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 24, Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(this, Ui.FOCUS, Ui.GOLD, 4, 29));
        bg.addState(new int[]{}, Ui.rect(this, Ui.glass(0xB8), Ui.GOLD, 1.5f, 29));
        Ui.button(t, bg);
        t.setOnClickListener(l);
        return put(t, x, 44, w, 58);
    }

    private View build() {
        Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));
        root.addView(new Scene(c, Scene.PAGE), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        stage.setClipChildren(false);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080));
        sp.gravity = Gravity.CENTER;
        root.addView(stage, sp);

        LocalDate d = LocalDate.now();

        put(Ui.box(c, "الأجبية", 62, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), 1100, 40, 750, 84);
        put(Ui.box(c, "صلوات الساعات السبع · " + Coptic.dateLine(d), 26, Ui.MUTED, Ui.alex(c), Ui.GR, 1), 700, 124, 1150, 34);

        pill("قراءات اليوم", 70, 210, v -> startActivity(new Intent(c, ReadingsActivity.class)));
        pill("ضبط المواقيت", 296, 220, v -> startActivity(new Intent(c, SettingsActivity.class)));
        TextView back = pill("رجوع", 532, 130, v -> finish());

        // clock card
        card(70, 210, 560, 290);
        clock = put(Ui.box(c, "", 112, Ui.CREAM, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1), 100, 226, 400, 140);
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        ampm = put(Ui.box(c, "", 30, Ui.GOLD, Ui.alexBold(c), Gravity.CENTER, 1), 508, 290, 100, 44);
        dateC = put(Ui.box(c, "", 28, Ui.GOLD, Ui.amiriBold(c), Gravity.CENTER_HORIZONTAL, 1), 90, 372, 520, 40);
        dateG = put(Ui.box(c, "", 24, Ui.MUTED, Ui.alex(c), Gravity.CENTER_HORIZONTAL, 1), 90, 412, 520, 32);
        nextPill = put(Ui.box(c, "", 24, Ui.INK, Ui.alexBold(c), Gravity.CENTER, 1), 110, 450, 480, 40);
        nextPill.setBackground(Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 20));

        // fast / feast card
        card(1290, 210, 560, 290);
        String feast = Coptic.feast(d);
        String fast = Coptic.fastToday(d);
        put(Ui.box(c, feast.isEmpty() ? "الصوم" : "مناسبة اليوم", 24, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 1320, 232, 500, 36);
        put(Ui.box(c, !feast.isEmpty() ? feast : (fast.isEmpty() ? "اليوم بدون صوم" : fast), 52, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 2), 1320, 272, 500, 120);
        Widgets.Bar bar = put(new Widgets.Bar(c), 1320, 412, 500, 14);
        int[] fp = Coptic.fastProgress(d);
        String line;
        if (fp[0] == 1) {
            bar.set(fp[1] / (float) fp[2]);
            line = "اليوم " + Coptic.ar(fp[1]) + " من " + Coptic.ar(fp[2]);
        } else {
            bar.set(1f - Math.min(fp[1], 90) / 90f);
            line = Coptic.nextFast(d);
        }
        put(Ui.box(c, line, 24, Ui.SOFT, Ui.alex(c), Ui.GR, 1), 1320, 440, 500, 40);

        // seven hours
        for (int i = 0; i < 7; i++) {
            final int idx = i;
            FrameLayout t = new FrameLayout(c);
            StateListDrawable bg = new StateListDrawable();
            bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, Ui.FOCUS, Ui.GOLD, 4, 22));
            bg.addState(new int[]{}, Ui.rect(c, Ui.glass(0xB8), 0x59D4AF6A, 1.5f, 22));
            Ui.button(t, bg);
            t.setLongClickable(true);
            t.setOnClickListener(v -> startActivity(new Intent(c, ReaderActivity.class)
                    .putExtra(ReaderActivity.EXTRA_HOUR, idx)));
            t.setOnLongClickListener(v -> {
                Agpeya.toggle(c, LocalDate.now(), idx);
                shownMask = -1;
                update();
                return true;
            });
            TextView name = Ui.box(c, Agpeya.NAMES[i], 28, Ui.CREAM, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
            times[i] = Ui.box(c, Agpeya.clock(Agpeya.minutes(c, i)), 38, Ui.GOLD, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 1);
            tags[i] = Ui.box(c, "", 20, Ui.MUTED, Ui.alex(c), Gravity.CENTER_HORIZONTAL, 1);
            t.addView(name, Ui.at(c, 8, 12, 226, 40));
            t.addView(times[i], Ui.at(c, 8, 54, 226, 52));
            t.addView(tags[i], Ui.at(c, 8, 106, 226, 28));
            tiles[i] = t;
            put(t, 70 + (6 - i) * 256, 650, 242, 140);
        }
        View hintBar = new View(c);
        hintBar.setBackground(Ui.rect(c, Ui.glass(0xB8), 0x00000000, 0, 18));
        put(hintBar, 70, 800, 1780, 42);
        put(Ui.box(c, "اضغط على الساعة لتقرأ الصلاة كاملة · اضغط مطولًا لتعليمها «صلّيت»", 22, Ui.SOFT, Ui.alex(c), Ui.GR, 1), 90, 806, 1740, 30);

        // verse
        card(70, 850, 1780, 170);
        String[] v = Verses.today(d);
        put(Ui.box(c, "«" + v[0] + "»", 44, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 2), 110, 862, 1700, 110);
        put(Ui.box(c, v[1], 26, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 110, 974, 1700, 34);

        back.post(() -> {
            int n = Agpeya.next(c, LocalDateTime.now().toLocalTime().toSecondOfDay());
            tiles[n].requestFocus();
        });
        return root;
    }

    private void update() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate d = now.toLocalDate();
        int sec = now.toLocalTime().toSecondOfDay();
        int h = now.getHour() % 12 == 0 ? 12 : now.getHour() % 12;
        Ui.setIfChanged(clock, Coptic.ar(h + ":" + (now.getMinute() < 10 ? "0" : "") + now.getMinute()));
        Ui.setIfChanged(ampm, now.getHour() < 12 ? "ص" : "م");
        Ui.setIfChanged(dateC, Coptic.dateLine(d));
        Ui.setIfChanged(dateG, Coptic.gregorianLine(d));
        int n = Agpeya.next(this, sec);
        Ui.setIfChanged(nextPill, "القادمة: " + Agpeya.NAMES[n] + " · " + Agpeya.countdown(Agpeya.secondsUntil(this, n, sec)));
        int mask = Agpeya.mask(this, d);
        if (mask != shownMask || n != shownNext) {
            shownMask = mask;
            shownNext = n;
            for (int i = 0; i < 7; i++) {
                boolean done = (mask & (1 << i)) != 0;
                tags[i].setText(done ? "✓ صلّيت" : (i == n ? "القادمة" : ""));
                tags[i].setTextColor(done ? 0xFF7FD6A4 : (i == n ? Ui.GOLD : Ui.MUTED));
            }
        }
    }
}
