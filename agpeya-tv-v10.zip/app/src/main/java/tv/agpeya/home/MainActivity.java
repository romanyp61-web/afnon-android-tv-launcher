package tv.agpeya.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * The home screen, laid out on a fixed 1920x1080 stage (scaled to the TV, always fully visible):
 * top bar, shortcuts, the church banner with the blessing and the next prayer, today's cards, and the apps.
 */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout stage;
    private Scene hero;
    private TextView clock, ampm, copticLine, gregLine, kicker, banner;
    private TextView nextName, nextCount, nextSub;
    private Widgets.Ring ring;
    private TextView fastLabel, fastMain, fastLine2, fastLine3;
    private Widgets.Bar fastBar;
    private TextView saintText, verseText, verseRef, prayBig, prayDots;
    private View quietShade;
    private final List<View> dock = new ArrayList<>();
    private View firstFocus, heroBtn;

    private float builtScale;
    private int builtTheme;
    private String shownDay = "";
    private int shownMask = -1;
    private int lastChime = -1;
    private int openHour = 0;
    private TextView soon;
    private String occasion = "";
    private String shownGreeting = "";

    private static final String HOUSE_VERSE = "«لتكن عيناك مفتوحتين على هذا البيت ليلًا ونهارًا»";

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        builtScale = Ui.fontScale(this);
        builtTheme = Ui.theme(this);
        setContentView(build());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Ui.fontScale(this) != builtScale || Ui.theme(this) != builtTheme) {
            recreate();
            return;
        }
        refreshApps();
        shownDay = "";
        shownMask = -1;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (firstFocus != null) firstFocus.requestFocus();
    }

    @Override
    public void onBackPressed() {
        // This is the home screen; there is nowhere to go back to.
    }

    // ---------------------------------------------------------------- helpers

    private <T extends View> T put(T v, float x, float y, float w, float h) {
        stage.addView(v, Ui.at(this, x, y, w, h));
        return v;
    }

    private View card(float x, float y, float w, float h) {
        View v = new View(this);
        v.setBackground(Ui.rect(this, Ui.glass(0xB8), 0x59D4AF6A, 1.5f, 26));
        return put(v, x, y, w, h);
    }

    private TextView pill(String label, float x, float y, float w, float h, boolean on, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 24, on ? Ui.INK : Ui.CREAM, Ui.alexBold(this));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused},
                Ui.rect(this, on ? 0xFFF3D698 : Ui.FOCUS, Ui.GOLD, 4, h / 2));
        bg.addState(new int[]{}, on ? Ui.rect(this, Ui.GOLD, Ui.GOLD, 0, h / 2)
                : Ui.rect(this, Ui.glass(0xB8), 0x66D4AF6A, 1.5f, h / 2));
        Ui.button(t, bg);
        t.setOnClickListener(l);
        return put(t, x, y, w, h);
    }

    private void shortcut(int i, String label, int glyph, int color, View.OnClickListener l) {
        float x = 1750, y = 140 + 138 * i;
        FrameLayout f = new FrameLayout(this);
        Ui.button(f, Ui.tile(this, Ui.glass(0xB8), 0x59D4AF6A, 26));
        f.setOnClickListener(l);
        View back = new View(this);
        back.setBackground(Ui.rect(this, color, color, 0, 14));
        f.addView(back, Ui.at(this, 32, 14, 46, 46));
        f.addView(new Widgets.Glyph(this, glyph), Ui.at(this, 32, 14, 46, 46));
        TextView t = Ui.box(this, label, 20, Ui.CREAM, Ui.alexBold(this), Gravity.CENTER_HORIZONTAL, 1);
        f.addView(t, Ui.at(this, 4, 68, 102, 36));
        put(f, x, y, 110, 116);
    }

    // ---------------------------------------------------------------- layout

    private View build() {
        Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.background(c));

        stage = new FrameLayout(c);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        stage.setClipChildren(false);
        root.addView(stage, new FrameLayout.LayoutParams(Ui.px(c, 1920), Ui.px(c, 1080), Gravity.CENTER));

        buildTopBar();
        buildShortcuts();
        buildHero();
        buildCards();

        quietShade = new View(c);
        quietShade.setBackgroundColor(0x4D000000);
        quietShade.setVisibility(View.GONE);
        root.addView(quietShade, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        return root;
    }

    private void buildTopBar() {
        Context c = this;
        View logo = new View(c);
        logo.setBackground(Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 16));
        put(logo, 1802, 39, 58, 58);
        CrossView cv = new CrossView(c);
        cv.tint(Ui.INK);
        put(cv, 1810, 47, 42, 42);
        put(Ui.box(c, "أجبية TV", 38, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 1), 1590, 36, 200, 62);

        pill("الرئيسية", 1440, 38, 140, 60, true, v -> { });
        pill("تطبيقاتي", 1276, 38, 146, 60, false, v -> startActivity(new Intent(this, AllAppsActivity.class)));
        pill("الأجبية", 1138, 38, 120, 60, false, v -> startActivity(new Intent(this, AgpeyaActivity.class)));
        pill("الإعدادات", 972, 38, 150, 60, false, v -> startActivity(new Intent(this, SettingsActivity.class)));

        clock = Ui.text(c, "", 66, Ui.CREAM, Ui.alexBold(c));
        clock.setTextDirection(View.TEXT_DIRECTION_LTR);
        clock.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        clock.setSingleLine(true);
        put(clock, 60, 26, 210, 80);
        ampm = Ui.text(c, "", 26, Ui.MUTED, Ui.alex(c));
        ampm.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        put(ampm, 276, 60, 50, 40);
        copticLine = Ui.box(c, "", 26, Ui.GOLD, Ui.alexBold(c), Gravity.LEFT, 1);
        put(copticLine, 340, 32, 560, 40);
        gregLine = Ui.box(c, "", 20, Ui.MUTED, Ui.alex(c), Gravity.LEFT, 1);
        put(gregLine, 340, 72, 560, 32);
    }

    private void buildShortcuts() {
        shortcut(0, "الأجبية", Widgets.Glyph.MOON, 0xFF3BA58D, v -> startActivity(new Intent(this, AgpeyaActivity.class)));
        shortcut(1, "القراءات", Widgets.Glyph.BOOK, 0xFF8B6CD9, v -> startActivity(new Intent(this, ReadingsActivity.class)));
        shortcut(2, "الألحان", Widgets.Glyph.NOTE, 0xFFE0709A, v -> Media.search(this, "ألحان وتسبحة قبطية أرثوذكسية"));
        shortcut(3, "الإعدادات", Widgets.Glyph.GEAR, 0xFFE8A23C, v -> startActivity(new Intent(this, SettingsActivity.class)));
    }

    private void buildHero() {
        Context c = this;
        hero = new Scene(c, Scene.HERO);
        hero.round(Ui.px(c, 34));
        put(hero, 60, 140, 1650, 460);

        View shade = new View(c);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT,
                new int[]{0xC707102A, 0x4D07102A, 0x0007102A});
        g.setCornerRadius(Ui.px(c, 34));
        shade.setBackground(g);
        put(shade, 60, 140, 1650, 460);
        View edge = new View(c);
        edge.setBackground(Ui.rect(c, 0x00000000, 0x59D4AF6A, 1.5f, 34));
        put(edge, 60, 140, 1650, 460);

        kicker = Ui.box(c, "", 26, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1);
        put(kicker, 900, 164, 754, 40);
        banner = Ui.text(c, "", 26, Ui.INK, Ui.alexBold(c));
        banner.setGravity(Gravity.CENTER);
        banner.setSingleLine(true);
        banner.setBackground(Ui.rect(c, Ui.GOLD, Ui.GOLD, 0, 20));
        banner.setVisibility(View.GONE);
        put(banner, 900, 164, 754, 40);

        put(Ui.box(c, "بارِك يا رب هذا البيت نهارًا وليلًا", 82, Ui.CREAM, Ui.amiriBold(c), Ui.GR, 1), 900, 206, 754, 96);
        put(Ui.box(c, HOUSE_VERSE, 34, 0xFFE6DCC4, Ui.amiri(c), Ui.GR, 2), 900, 304, 754, 90);
        put(Ui.box(c, "الملوك الأول ٨: ٢٩", 22, Ui.MUTED, Ui.alex(c), Ui.GR, 1), 900, 396, 754, 32);
        put(Ui.box(c, "إيلينا وكيفين", 50, Ui.GOLD, Ui.amiriBold(c), Ui.GR, 1), 900, 432, 754, 78);

        soon = Ui.box(c, "", 24, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1);
        put(soon, 900, 534, 430, 40);

        TextView btn = Ui.text(c, "قراءات اليوم والسنكسار", 24, Ui.INK, Ui.alexBold(c));
        btn.setGravity(Gravity.CENTER);
        btn.setSingleLine(true);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, Ui.rect(c, Ui.CREAM, Ui.GOLD, 5, 32));
        bg.addState(new int[]{}, Ui.rect(c, Ui.CREAM, Ui.CREAM, 0, 32));
        Ui.button(btn, bg);
        btn.setOnClickListener(v -> startActivity(new Intent(this, ReadingsActivity.class)));
        put(btn, 1346, 522, 308, 64);
        heroBtn = btn;

        // next prayer, with a ring that empties
        View nextCard = new View(c);
        Ui.button(nextCard, Ui.tile(c, 0xA007102A, 0x73D4AF6A, 24));
        nextCard.setOnClickListener(v -> startActivity(new Intent(this, ReaderActivity.class)
                .putExtra(ReaderActivity.EXTRA_HOUR, openHour)));
        put(nextCard, 100, 312, 300, 268);
        put(Ui.box(c, "الصلاة القادمة", 20, Ui.MUTED, Ui.alex(c), Ui.GC, 1), 110, 322, 280, 28);
        nextName = Ui.box(c, "", 40, Ui.GOLD, Ui.amiriBold(c), Ui.GC, 1);
        put(nextName, 110, 348, 280, 54);
        ring = new Widgets.Ring(c);
        put(ring, 175, 406, 150, 150);
        nextCount = Ui.text(c, "", 27, Ui.CREAM, Ui.alexBold(c));
        nextCount.setGravity(Gravity.CENTER);
        nextCount.setSingleLine(true);
        nextCount.setTextDirection(View.TEXT_DIRECTION_LTR);
        put(nextCount, 175, 406, 150, 150);
        nextSub = Ui.box(c, "", 19, Ui.MUTED, Ui.alex(c), Ui.GC, 1);
        put(nextSub, 110, 552, 280, 26);
    }

    private void buildCards() {
        Context c = this;
        final float y = 620, h = 170;

        // prayers done today (left)
        View pray = card(60, y, 291, h);
        Ui.button(pray, Ui.tile(c, Ui.glass(0xB8), 0x59D4AF6A, 26));
        pray.setOnClickListener(v -> startActivity(new Intent(this, AgpeyaActivity.class)));
        put(Ui.box(c, "صلواتي اليوم", 22, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 80, y + 12, 251, 28);
        prayBig = Ui.box(c, "", 44, Ui.CREAM, Ui.alexBold(c), Ui.GR, 1);
        put(prayBig, 80, y + 44, 251, 60);
        prayDots = Ui.box(c, "", 26, Ui.GOLD, Ui.alex(c), Ui.GR, 1);
        put(prayDots, 80, y + 108, 251, 36);
        put(Ui.box(c, "اضغط لفتح الأجبية", 18, Ui.MUTED, Ui.alex(c), Ui.GR, 1), 80, y + 142, 251, 24);

        // verse of the day
        card(367, y, 546, h);
        put(Ui.box(c, "آية اليوم", 22, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 387, y + 12, 506, 28);
        verseText = Ui.box(c, "", 28, Ui.CREAM, Ui.amiri(c), Ui.GR, 3);
        verseText.setLineSpacing(0, 0.85f);
        put(verseText, 387, y + 42, 506, 98);
        verseRef = Ui.box(c, "", 20, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        put(verseRef, 387, y + 142, 506, 24);

        // saint of the day
        View saint = card(929, y, 400, h);
        Ui.button(saint, Ui.tile(c, Ui.glass(0xB8), 0x59D4AF6A, 26));
        saint.setOnClickListener(v -> startActivity(new Intent(this, ReadingsActivity.class)));
        put(Ui.box(c, "قديس اليوم", 22, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1), 949, y + 12, 360, 28);
        put(new Widgets.Halo(c), 1245, y + 52, 64, 64);
        saintText = Ui.box(c, "", 26, Ui.CREAM, Ui.alexBold(c), Ui.GR, 4);
        put(saintText, 949, y + 46, 280, 112);

        // fast or feast (right)
        card(1345, y, 365, h);
        fastLabel = Ui.box(c, "الصوم", 22, Ui.GOLD, Ui.alexBold(c), Ui.GR, 1);
        put(fastLabel, 1365, y + 12, 325, 28);
        fastMain = Ui.box(c, "", 30, Ui.CREAM, Ui.alexBold(c), Ui.GR, 1);
        put(fastMain, 1365, y + 42, 325, 40);
        fastLine2 = Ui.box(c, "", 21, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        put(fastLine2, 1365, y + 84, 325, 30);
        fastBar = new Widgets.Bar(c);
        put(fastBar, 1365, y + 124, 325, 8);
        fastLine3 = Ui.box(c, "", 20, Ui.MUTED, Ui.alex(c), Ui.GR, 1);
        put(fastLine3, 1365, y + 136, 325, 28);
    }

    // ---------------------------------------------------------------- apps

    private void refreshApps() {
        Context c = this;
        for (View v : dock) stage.removeView(v);
        dock.clear();

        final List<Apps.App> all = Apps.list(c);
        List<Apps.App> shown = new ArrayList<>();
        for (String p : Apps.favoritePackages(c, all))
            for (Apps.App a : all) if (a.pkg.equals(p) && !shown.contains(a)) shown.add(a);
        for (Apps.App a : all) {
            if (shown.size() >= 6) break;
            if (!shown.contains(a)) shown.add(a);
        }
        int n = Math.min(6, shown.size());
        float startX = 60 + (1650 - (7 * 150 + 6 * 24)) / 2f;
        for (int i = 0; i < n; i++) {
            final Apps.App a = shown.get(i);
            View t = dockTile(a.icon, null, a.label);
            t.setOnClickListener(v -> Apps.launch(this, a.pkg));
            put(t, startX + i * 174, 806, 150, 176);
            dock.add(t);
        }
        View allTile = dockTile(null, new Widgets.Glyph(c, Widgets.Glyph.GRID), "كل التطبيقات " + Coptic.ar(all.size()));
        allTile.setOnClickListener(v -> startActivity(new Intent(this, AllAppsActivity.class)));
        put(allTile, startX + n * 174, 806, 150, 176);
        dock.add(allTile);

        firstFocus = n > 0 ? dock.get(0) : heroBtn;
        firstFocus.requestFocus();
    }

    private View dockTile(android.graphics.drawable.Drawable icon, View glyph, String label) {
        Context c = this;
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, Ui.px(c, 14), 0, 0);
        Ui.button(t, Ui.tile(c, Ui.glass(0x99), 0x59D4AF6A, 28));
        if (icon != null) {
            ImageView iv = new ImageView(c);
            iv.setImageDrawable(icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            t.addView(iv, Ui.lp(c, 100, 100));
        } else {
            FrameLayout f = new FrameLayout(c);
            View back = new View(c);
            back.setBackground(Ui.rect(c, 0xFF445B8F, 0xFF445B8F, 0, 24));
            f.addView(back, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            f.addView(glyph, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            t.addView(f, Ui.lp(c, 100, 100));
        }
        Ui.gap(c, t, 8);
        t.addView(Ui.box(c, label, 22, Ui.CREAM, Ui.alexBold(c), Gravity.CENTER_HORIZONTAL, 2), Ui.lp(c, 138, 46));
        return t;
    }

    // ---------------------------------------------------------------- ticking

    private static String greeting(int hour) {
        if (hour >= 5 && hour < 12) return "صباح الخير يا إيلينا وكيفين";
        if (hour >= 12 && hour < 17) return "نهارك سعيد يا إيلينا وكيفين";
        if (hour >= 17 && hour < 21) return "مساء الخير يا إيلينا وكيفين";
        return "ليلة هادئة يا إيلينا وكيفين";
    }

    private static String minutesWord(int n) {
        if (n <= 1) return "دقيقة واحدة";
        if (n == 2) return "دقيقتين";
        return Coptic.ar(n) + " دقائق";
    }

    private void update() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        int sec = now.toLocalTime().toSecondOfDay();

        int h = now.getHour(), m = now.getMinute();
        int h12 = h % 12 == 0 ? 12 : h % 12;
        Ui.setIfChanged(clock, Coptic.ar(h12 + ":" + (m < 10 ? "0" : "") + m));
        Ui.setIfChanged(ampm, h < 12 ? "ص" : "م");

        String dayKey = today.toString();
        if (!dayKey.equals(shownDay)) {
            shownDay = dayKey;
            refreshDay(today);
        }

        // next prayer
        int next = Agpeya.next(this, sec);
        int until = Agpeya.secondsUntil(this, next, sec);
        int since = Agpeya.secondsSince(this, sec);
        Ui.setIfChanged(nextName, Agpeya.NAMES[next]);
        Ui.setIfChanged(nextCount, Agpeya.countdown(until));
        Ui.setIfChanged(nextSub, "الساعة " + Agpeya.clock(Agpeya.minutes(this, next)));
        ring.set(since / (float) Math.max(1, since + until));

        // reminder: 10 minutes before an hour, and 15 minutes after it starts
        int prev = 0, best = Integer.MAX_VALUE;
        for (int i = 0; i < 7; i++) {
            int s = sec - Agpeya.minutes(this, i) * 60;
            if (s < 0) s += 86400;
            if (s < best) {
                best = s;
                prev = i;
            }
        }
        openHour = until <= 600 ? next : (best <= 900 ? prev : next);
        if (until <= 600) {
            Ui.setIfChanged(banner, "اقترب وقت صلاة " + Agpeya.NAMES[next] + " — بعد " + minutesWord((until + 59) / 60));
            banner.setVisibility(View.VISIBLE);
            kicker.setVisibility(View.INVISIBLE);
        } else if (best <= 900) {
            Ui.setIfChanged(banner, "حان وقت صلاة " + Agpeya.NAMES[prev] + " — صلِّ الآن");
            banner.setVisibility(View.VISIBLE);
            kicker.setVisibility(View.INVISIBLE);
        } else {
            banner.setVisibility(View.GONE);
            kicker.setVisibility(View.VISIBLE);
        }

        String g = greeting(h);
        if (!g.equals(shownGreeting)) {
            shownGreeting = g;
            applyKicker(today);
        }

        // prayers done today
        int mask = Agpeya.mask(this, today);
        if (mask != shownMask) {
            shownMask = mask;
            prayBig.setText(Coptic.ar(Integer.bitCount(mask)) + " من ٧");
            StringBuilder dots = new StringBuilder();
            for (int k = 0; k < 7; k++) dots.append(((mask >> k) & 1) == 1 ? "●" : "○").append(k < 6 ? " " : "");
            prayDots.setText(dots.toString());
        }

        // soft bell at the start of an hour (daytime only)
        int minuteOfDay = h * 60 + m;
        if (now.getSecond() < 3 && minuteOfDay != lastChime && h >= 5 && h <= 21 && Chime.enabled(this)) {
            for (int i = 0; i < 7; i++) {
                if (Agpeya.minutes(this, i) == minuteOfDay) {
                    lastChime = minuteOfDay;
                    Chime.play(this);
                    break;
                }
            }
        }

        // quiet mode after 9 pm until 5 am
        boolean quiet = Ui.quiet(this) && (h >= 21 || h < 5);
        quietShade.setVisibility(quiet ? View.VISIBLE : View.GONE);
    }

    private void applyKicker(LocalDate d) {
        String feast = Coptic.feast(d);
        kicker.setText(!occasion.isEmpty() ? occasion
                : feast.isEmpty() ? shownGreeting : "كل سنة وإنتم طيبين · " + feast);
    }

    private void refreshDay(LocalDate d) {
        int[] c = Coptic.of(d);
        Ui.setIfChanged(copticLine, Coptic.dateLine(d));
        Ui.setIfChanged(gregLine, Coptic.gregorianLine(d));

        String feast = Coptic.feast(d);
        String fast = Coptic.fastToday(d);
        LocalDate tm = d.plusDays(1);
        String tomorrow = Coptic.feast(tm);
        if (tomorrow.isEmpty()) {
            String f = Coptic.fastToday(tm);
            tomorrow = f.isEmpty() ? "بدون صوم" : f;
        }
        fastLabel.setText(feast.isEmpty() ? "الصوم" : "مناسبة اليوم");
        fastMain.setText(!feast.isEmpty() ? feast : (fast.isEmpty() ? "اليوم بدون صوم" : fast));
        fastLine2.setText("بكرة: " + tomorrow);
        int[] fp = Coptic.fastProgress(d);
        if (fp[0] == 1) {
            fastBar.set(fp[1] / (float) fp[2]);
            fastLine3.setText("اليوم " + Coptic.ar(fp[1]) + " من " + Coptic.ar(fp[2]));
        } else {
            fastBar.set(1f - Math.min(fp[1], 90) / 90f);
            fastLine3.setText(Coptic.nextFast(d));
        }

        String[] v = Verses.today(d);
        verseText.setText(v[0]);
        verseRef.setText(v[1]);

        JSONObject day = Readings.day(this, c[1], c[2]);
        String[] titles = Readings.titles(day);
        saintText.setText(titles.length == 0 ? "سنكسار هذا الشهر غير مضاف بعد" : titles[0]);

        hero.setFasting(Coptic.majorFast(d) != null);
        int type = 0;
        if (!feast.isEmpty()) {
            if (feast.contains("الميلاد")) type = 1;
            else if (feast.contains("القيامة") || feast.contains("العنصرة") || feast.contains("الصعود")) type = 2;
            else type = 3;
        }
        hero.setFeast(type);
        occasion = Occasions.today(d);
        String up = Occasions.upcoming(d);
        soon.setText(up);
        soon.setVisibility(up.isEmpty() ? View.INVISIBLE : View.VISIBLE);
        applyKicker(d);
    }
}
