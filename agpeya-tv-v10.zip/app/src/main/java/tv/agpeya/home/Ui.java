package tv.agpeya.home;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

/** Small helpers so the screens can be written once at 1920x1080 and scale to any TV. */
final class Ui {
    private Ui() {}

    static final int GOLD = 0xFFD4AF6A;
    static final int CREAM = 0xFFF3ECDD;
    static int NAVY = 0xFF0C1B33, PANEL = 0xFF13264A, PANEL2 = 0xFF0F2243, LINE = 0xFF243A63;
    static int MUTED = 0xFFA9B8D3, SOFT = 0xFFD9E1F0, FOCUS = 0xFF1C3763, INK = 0xFF0C1B33;
    static int ARCH = 0xFF12264A, EDGE = 0xFF2A4270;

    static final String[] THEMES = {"أزرق", "بوردو", "أخضر"};
    private static int themeId = -1;

    static int theme(Context c) {
        if (themeId < 0) themeId = c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getInt("theme", 0);
        return themeId;
    }

    static void setTheme(Context c, int t) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putInt("theme", t).apply();
        themeId = t;
        init(c);
    }

    /** Call at the start of every screen: loads the chosen colours. */
    static void init(Context c) {
        switch (theme(c)) {
            case 1:
                NAVY = INK = 0xFF2A0F16; PANEL = 0xFF3B1620; PANEL2 = 0xFF33131C; LINE = 0xFF5A2A36;
                MUTED = 0xFFCDB5B1; SOFT = 0xFFEBDDD9; FOCUS = 0xFF4D1D2B; ARCH = 0xFF3A1520; EDGE = 0xFF6B3441;
                break;
            case 2:
                NAVY = INK = 0xFF0E2217; PANEL = 0xFF153526; PANEL2 = 0xFF112B1F; LINE = 0xFF2A5440;
                MUTED = 0xFFB2C9BB; SOFT = 0xFFDCEBE2; FOCUS = 0xFF1F4A35; ARCH = 0xFF143124; EDGE = 0xFF3A6B52;
                break;
            default:
                NAVY = INK = 0xFF0C1B33; PANEL = 0xFF13264A; PANEL2 = 0xFF0F2243; LINE = 0xFF243A63;
                MUTED = 0xFFA9B8D3; SOFT = 0xFFD9E1F0; FOCUS = 0xFF1C3763; ARCH = 0xFF12264A; EDGE = 0xFF2A4270;
        }
    }

    /** The screen background: the theme colour with faint see-through crosses all over it. */
    static android.graphics.drawable.Drawable background(Context c) {
        final int s = Math.max(40, px(c, 140));
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(s, s, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas cv = new android.graphics.Canvas(bmp);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setColor(GOLD);
        p.setAlpha(41);
        p.setStyle(android.graphics.Paint.Style.STROKE);
        p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        p.setStrokeWidth(Math.max(1.5f, 3 * k(c)));
        float m = s / 2f, arm = s * 18f / 140, tip = s * 6f / 140;
        cv.drawLine(m, m - arm, m, m + arm, p);
        cv.drawLine(m - arm, m, m + arm, m, p);
        cv.drawLine(m - tip, m - arm, m + tip, m - arm, p);
        cv.drawLine(m - tip, m + arm, m + tip, m + arm, p);
        cv.drawLine(m - arm, m - tip, m - arm, m + tip, p);
        cv.drawLine(m + arm, m - tip, m + arm, m + tip, p);
        final android.graphics.Paint fill = new android.graphics.Paint();
        fill.setShader(new android.graphics.BitmapShader(bmp, android.graphics.Shader.TileMode.REPEAT,
                android.graphics.Shader.TileMode.REPEAT));
        final int base = NAVY;
        return new android.graphics.drawable.Drawable() {
            @Override
            public void draw(android.graphics.Canvas canvas) {
                canvas.drawColor(base);
                canvas.drawRect(getBounds(), fill);
            }

            @Override
            public void setAlpha(int alpha) {}

            @Override
            public void setColorFilter(android.graphics.ColorFilter cf) {}

            @Override
            public int getOpacity() {
                return android.graphics.PixelFormat.OPAQUE;
            }
        };
    }

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static Typeface amiri, amiriBold, alex, alexBold;

    private static float fontScale = -1f;

    /** 1.0 normally, 1.15 when "big text" is on in Settings. */
    static float fontScale(Context c) {
        if (fontScale < 0)
            fontScale = c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getBoolean("big", false) ? 1.15f : 1f;
        return fontScale;
    }

    static boolean isBig(Context c) {
        return fontScale(c) > 1f;
    }

    static void setBig(Context c, boolean big) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putBoolean("big", big).apply();
        fontScale = big ? 1.15f : 1f;
    }

    /** 1.0 on a 1920 px wide screen. */
    static float k(Context c) {
        android.util.DisplayMetrics m = c.getResources().getDisplayMetrics();
        return Math.max(0.5f, Math.min(m.widthPixels / 1920f, m.heightPixels / 1080f));
    }

    /** Places a view on the fixed 1920x1080 stage (design pixels, from the top-left corner). */
    static android.widget.FrameLayout.LayoutParams at(Context c, float x, float y, float w, float h) {
        android.widget.FrameLayout.LayoutParams p = new android.widget.FrameLayout.LayoutParams(px(c, w), px(c, h));
        p.leftMargin = px(c, x);
        p.topMargin = px(c, y);
        p.gravity = android.view.Gravity.TOP | android.view.Gravity.LEFT;
        return p;
    }

    /** A see-through panel colour (for cards over the pictures). */
    static int glass(int alpha) {
        return (alpha << 24) | (PANEL & 0xFFFFFF);
    }

    static final int GR = android.view.Gravity.RIGHT, GC = android.view.Gravity.CENTER_HORIZONTAL;

    /** A text box with a fixed area on the stage: the text shrinks to fit instead of spilling out. */
    static TextView box(Context c, String s, float size, int color, Typeface tf, int hGravity, int maxLines) {
        TextView t = text(c, s, size, color, tf);
        t.setGravity(hGravity | android.view.Gravity.CENTER_VERTICAL);
        t.setMaxLines(maxLines);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setAutoSizeTextTypeUniformWithConfiguration(Math.max(1, Math.round(size * 0.5f * k(c))),
                Math.max(2, Math.round(size * k(c))), 1, TypedValue.COMPLEX_UNIT_PX);
        return t;
    }

    /** Bigger letters on the prayer-reading screen only (Settings). */
    static boolean readerBig(Context c) {
        return c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getBoolean("rbig", false);
    }

    static void setReaderBig(Context c, boolean on) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putBoolean("rbig", on).apply();
    }

    static boolean quiet(Context c) {
        return c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getBoolean("quiet", true);
    }

    static void setQuiet(Context c, boolean on) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putBoolean("quiet", on).apply();
    }

    static int px(Context c, float v) {
        return Math.round(v * k(c));
    }

    /** Design pixels to real pixels, but MATCH/WRAP (negative) pass through. */
    static int d(Context c, float v) {
        return v < 0 ? (int) v : px(c, v);
    }

    static Typeface amiri(Context c) {
        if (amiri == null) amiri = c.getResources().getFont(R.font.amiri_regular);
        return amiri;
    }

    static Typeface amiriBold(Context c) {
        if (amiriBold == null) amiriBold = c.getResources().getFont(R.font.amiri_bold);
        return amiriBold;
    }

    static Typeface alex(Context c) {
        if (alex == null) alex = c.getResources().getFont(R.font.alexandria_regular);
        return alex;
    }

    static Typeface alexBold(Context c) {
        if (alexBold == null) alexBold = c.getResources().getFont(R.font.alexandria_semibold);
        return alexBold;
    }

    static GradientDrawable rect(Context c, int fill, int stroke, float strokeW, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(px(c, radius));
        if (strokeW > 0) g.setStroke(Math.max(1, px(c, strokeW)), stroke);
        return g;
    }

    /** Tile background: plain at rest, bright gold edge when the remote focuses it. */
    static StateListDrawable tile(Context c, int fill, int line, float radius) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, rect(c, FOCUS, GOLD, 4, radius));
        s.addState(new int[]{}, rect(c, fill, line, 1, radius));
        return s;
    }

    static TextView text(Context c, String s, float size, int color, Typeface tf) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTypeface(tf);
        t.setIncludeFontPadding(false);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * k(c) * fontScale(c));
        return t;
    }

    static LinearLayout.LayoutParams lp(Context c, float w, float h) {
        return new LinearLayout.LayoutParams(d(c, w), d(c, h));
    }

    static LinearLayout.LayoutParams lpw(Context c, float w, float h, float weight) {
        return new LinearLayout.LayoutParams(d(c, w), d(c, h), weight);
    }

    /** A fixed gap between siblings. */
    static void gap(Context c, LinearLayout parent, float size) {
        Space sp = new Space(c);
        boolean horizontal = parent.getOrientation() == LinearLayout.HORIZONTAL;
        parent.addView(sp, horizontal ? lp(c, size, 1) : lp(c, 1, size));
    }

    /** Makes a view a remote-friendly button: focusable, clickable, grows a little when focused. */
    static void button(View v, android.graphics.drawable.Drawable bg) {
        v.setFocusable(true);
        v.setClickable(true);
        v.setBackground(bg);
        v.setOnFocusChangeListener((view, has) ->
                view.animate().scaleX(has ? 1.04f : 1f).scaleY(has ? 1.04f : 1f).setDuration(120).start());
    }

    static void setIfChanged(TextView t, String s) {
        if (!s.contentEquals(t.getText())) t.setText(s);
    }
}
