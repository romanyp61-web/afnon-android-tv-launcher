package tv.agpeya.home;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

/** A soft bell, made on the spot (no sound file), played at the start of each Agpeya hour. */
final class Chime {
    private Chime() {}

    static boolean enabled(Context c) {
        return c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).getBoolean("chime", true);
    }

    static void setEnabled(Context c, boolean on) {
        c.getSharedPreferences("agpeya", Context.MODE_PRIVATE).edit().putBoolean("chime", on).apply();
    }

    static void play(Context c) {
        try {
            final int rate = 22050;
            final int n = (int) (rate * 2.6);
            short[] pcm = new short[n];
            double[] ratio = {1.0, 2.0, 2.76, 5.4};
            double[] amp = {1.0, 0.6, 0.35, 0.15};
            double[] decay = {1.8, 2.5, 3.5, 5.0};
            for (int i = 0; i < n; i++) {
                double t = i / (double) rate;
                double v = 0;
                for (int k = 0; k < ratio.length; k++) {
                    v += amp[k] * Math.sin(2 * Math.PI * 440.0 * ratio[k] * t) * Math.exp(-t * decay[k]);
                }
                double fade = Math.min(1.0, t * 200.0); // no click at the start
                pcm[i] = (short) (v / 2.1 * 0.55 * fade * 32767);
            }
            final AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(n * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            track.write(pcm, 0, n);
            track.play();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    track.release();
                } catch (Exception ignored) {
                }
            }, 3500);
        } catch (Exception ignored) {
            // no sound is better than a crash on the home screen
        }
    }
}
