package tv.agpeya.home;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Daily readings and synaxarium titles, from assets/data/MM.json (MM = Coptic month, 01..13). */
final class Readings {
    private Readings() {}

    private static final Map<Integer, JSONObject> CACHE = new HashMap<>();

    /** One day's JSON object, or null when that month has not been added. */
    static JSONObject day(Context c, int month, int day) {
        JSONObject m = CACHE.get(month);
        if (m == null) {
            try {
                InputStream in = c.getAssets().open(String.format(Locale.ROOT, "data/%02d.json", month));
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                m = new JSONObject(out.toString("UTF-8"));
            } catch (Exception e) {
                m = new JSONObject();
            }
            CACHE.put(month, m);
        }
        return m.optJSONObject(Integer.toString(day));
    }

    static String get(JSONObject d, String key) {
        return d == null ? "" : d.optString(key, "");
    }

    static String[] titles(JSONObject d) {
        if (d == null) return new String[0];
        JSONArray a = d.optJSONArray("syn");
        if (a == null) return new String[0];
        String[] r = new String[a.length()];
        for (int i = 0; i < r.length; i++) r[i] = a.optString(i);
        return r;
    }
}
